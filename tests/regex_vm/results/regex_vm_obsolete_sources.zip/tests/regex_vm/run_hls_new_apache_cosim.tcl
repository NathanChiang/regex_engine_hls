set here [file dirname [file normalize [info script]]]
set root [file normalize "$here/../.."]
if {[info exists ::env(DEBUG)]} { unset ::env(DEBUG) }
if {[info exists ::env(REGEX_ENGINE_ROOT)]} {
    set root [file normalize $::env(REGEX_ENGINE_ROOT)]
}
cd "$here/build"
# CoSim's generated wrapper makefiles capture host environment flags.  Always
# regenerate them after sanitizing DEBUG so a failed/stale wrapper cannot be
# reused by the next correctness run.
file delete -force "$here/build/regex_vm_new_perf/sol/sim"
open_project regex_vm_new_perf
set_top regex_vm_new_perf
add_files -tb "$here/regex_vm_new_apache.cpp" \
    -cflags "-std=c++14 -DCOSIM_TOP -I$root/include/hw"
open_solution sol
cosim_design -rtl verilog -trace_level none \
    -argv "$root/hls/build/cosim_re_engine_direct_log_validation/cosim_input.txt"
exit
