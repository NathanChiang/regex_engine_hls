set here [file dirname [file normalize [info script]]]
set root [file normalize "$here/../.."]
if {[info exists ::env(DEBUG)]} { unset ::env(DEBUG) }
file mkdir "$here/build"
cd "$here/build"
open_project class_config_probe
set_top class_config_probe
set flags "-std=c++14 -I$root/include/hw"
add_files "$here/class_config_probe.cpp" -cflags $flags
add_files -tb "$here/test_class_config_probe.cpp" -cflags $flags
open_solution -flow_target vivado sol
set_part xcvc1902-vsva2197-2MP-e-S
create_clock -period 6
config_compile -pipeline_loops 0
config_array_partition -throughput_driven off
csim_design -clean
csynth_design
cosim_design -rtl verilog -trace_level none
exit
